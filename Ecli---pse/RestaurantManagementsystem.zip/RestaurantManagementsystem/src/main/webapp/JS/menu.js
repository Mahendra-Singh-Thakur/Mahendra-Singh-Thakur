document.addEventListener("DOMContentLoaded", () => {
    const menuItems = [
        { id: 1, name: 'Cheeseburger', description: 'Juicy beef patty with cheddar cheese', price: 8.99 },
        { id: 2, name: 'Caesar Salad', description: 'Fresh romaine lettuce with Caesar dressing', price: 6.49 },
        { id: 3, name: 'Margherita Pizza', description: 'Classic pizza with tomato sauce and mozzarella', price: 10.99 },
        { id: 4, name: 'Spaghetti Carbonara', description: 'Spaghetti with creamy sauce and bacon', price: 12.99 },
        { id: 5, name: 'Chocolate Brownie', description: 'Rich chocolate brownie with ice cream', price: 4.99 },
        { id: 6, name: 'Grilled Chicken Sandwich', description: 'Grilled chicken breast with lettuce and mayo', price: 9.49 },
        { id: 7, name: 'Fish and Chips', description: 'Crispy fried fish with French fries', price: 11.49 },
        { id: 8, name: 'Vegetable Stir-Fry', description: 'Assorted vegetables stir-fried in soy sauce', price: 8.29 },
        { id: 9, name: 'Penne Arrabbiata', description: 'Penne pasta in spicy tomato sauce', price: 10.49 },
        { id: 10, name: 'Mixed Berry Smoothie', description: 'Blend of mixed berries with yogurt', price: 5.99 },
        { id: 11, name: 'Classic Caesar Salad', description: 'Traditional Caesar salad with croutons', price: 7.99 },
        { id: 12, name: 'BBQ Ribs', description: 'Slow-cooked BBQ pork ribs with coleslaw', price: 15.99 },
        { id: 13, name: 'Mushroom Risotto', description: 'Creamy risotto with mushrooms and Parmesan', price: 13.49 },
        { id: 14, name: 'Tiramisu', description: 'Italian dessert with coffee-soaked ladyfingers', price: 6.99 },
        { id: 15, name: 'Chicken Tikka Masala', description: 'Indian curry with chicken in creamy tomato sauce', price: 11.99 }
    ];

    const cartItems = [];
    const menuContainer = document.getElementById("menuContainer");
    const cartItemsContainer = document.getElementById("cartItems");
    const totalPriceElement = document.getElementById("totalPrice");

    function updateCart() {
        cartItemsContainer.innerHTML = "";
        let totalPrice = 0;
        cartItems.forEach(item => {
            const itemElement = document.createElement("div");
            itemElement.className = "cartItem";
            itemElement.innerText = `${item.name} - $${item.price.toFixed(2)}`;
            cartItemsContainer.appendChild(itemElement);
            totalPrice += item.price;
        });
        totalPriceElement.innerText = `Total: $${totalPrice.toFixed(2)}`;
    }

    function createMenuItem(item) {
        const menuItem = document.createElement("div");
        menuItem.className = "menuItem";

        const itemName = document.createElement("h2");
        itemName.innerText = item.name;

        const itemDescription = document.createElement("p");
        itemDescription.innerText = item.description;

        const itemPrice = document.createElement("p");
        itemPrice.className = "price";
        itemPrice.innerText = `$${item.price.toFixed(2)}`;

        const addToCartButton = document.createElement("button");
        addToCartButton.className = "addToCart";
        addToCartButton.innerText = "Add to Cart";
        addToCartButton.addEventListener("click", () => {
            cartItems.push(item);
            updateCart();
        });

        menuItem.appendChild(itemName);
        menuItem.appendChild(itemDescription);
        menuItem.appendChild(itemPrice);
        menuItem.appendChild(addToCartButton);

        menuContainer.appendChild(menuItem);
    }

    menuItems.forEach(createMenuItem);
});
